/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import java.util.ArrayList;

/**
 *
 * @author User
 */
public class MakeBDCliente {
    private static MakeBDCliente clt;
    private static ArrayList <Cliente> clientes;
    

    public MakeBDCliente() {
        clientes = new ArrayList <Cliente> ();
    }
    
    public static MakeBDCliente getBDCliente ( ){
        clientes = new ArrayList <Cliente> ();
        if (clt == null) {
            clt = new MakeBDCliente();
        }
        return clt;
    }

    public static void setListClientes(ArrayList<Cliente> clientes) {
        MakeBDCliente.clientes = clientes;
    }

    public static ArrayList<Cliente> getListClientes() {
        return clientes;
    }
}