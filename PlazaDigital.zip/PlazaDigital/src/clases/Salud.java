/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author User
 */
public class Salud extends Categoria implements ICategoriaMyC{

    public Salud() {
        super.setNombre("Salud");
    }
    
    public String beneficioProd (){
        return "Este producto est� publicado par satisfacer sus necesidades respecta a la salud";
    }
    
    public void myCategoria (){
        System.out.println("La categoria de este producto es: Salud");
    }
}