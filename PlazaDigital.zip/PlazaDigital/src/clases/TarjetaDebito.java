/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class TarjetaDebito extends Pago {
    Scanner in = new Scanner (System.in);
    private final String numTarjeta;

    public TarjetaDebito(String numTarjeta) {
        this.numTarjeta = numTarjeta;
    }
    
    public String getNumTarjeta() {
        return numTarjeta;
    }

    @Override
    public Pago soliciarDatos(double cantDinero) {
        super.setCantDinero(cantDinero);
        System.out.print("Ingrese el numero de la tarjeta debito: ");
        String numTarjeta = in.nextLine();
        return new TarjetaDebito (numTarjeta);
    }
}