/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import java.util.ArrayList;

/**
 *
 * @author User
 */
public class Proveedor {
    private final String nombre;
    private final String id;
    private final String nCelular;
    private ArrayList <Producto> listProd;

    public Proveedor(String nombre, String id, String nCelular, Producto producto) {
        this.nombre = nombre;
        this.id = id;
        this.nCelular = nCelular;
        listProd= new ArrayList <Producto> ();
        listProd.add(producto);
    }
    
    public void publicarProducto (Producto producto){
        listProd.add(producto);
    }
    
    public String consultarEstadisticas (String referencia){
        for(int i=0; i<listProd.size(); i++){
            Producto prod=listProd.get(i);
            if(prod.getReferencia().equalsIgnoreCase(referencia))
                return ("Unidades vendidas de este producto: " +prod.getVendidos());   
        }
        return ("Esa referencia no hace parte de sus productos, por lo tanto no puede ver las estadisticas del mismo");
    }
    
    public void eliminarProducto (String referencia){
        for(int i=0; i<listProd.size(); i++){
            Producto prod=listProd.get(i);
            if(prod.getReferencia().equalsIgnoreCase(referencia)){
                listProd.remove(i);
                System.out.println("Se elimino satisfactoriamente");
            }
        }
    }

    public ArrayList<Producto> getListProd() {
        return listProd;
    }

    public void setListProd(ArrayList<Producto> listProd) {
        this.listProd = listProd;
    }

    public String getNombre() {
        return nombre;
    }

    public String getId() {
        return id;
    }

    public String getnCelular() {
        return nCelular;
    }

    @Override
    public String toString() {
        return "Proveedor{" + "nombre=" + nombre + ", id=" + id + ", nCelular=" + nCelular + ", listProd=" + listProd + '}';
    }
}