/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class TarjetaCredito extends Pago{
    Scanner in = new Scanner (System.in);
    private final String nTarjeta;

    public TarjetaCredito(String nTarjeta) {
        this.nTarjeta = nTarjeta;
    }
    
    public String getNTarjeta() {
        return nTarjeta;
    }

    @Override
    public Pago soliciarDatos(double cantDinero) {
        super.setCantDinero(cantDinero);
        System.out.print("Ingrese el numero de la tarjeta credito: ");
        String nTarjeta = in.nextLine();
        return new TarjetaCredito (nTarjeta);
    }
}