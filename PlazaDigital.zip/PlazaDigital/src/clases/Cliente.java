/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class Cliente {
    
    private final String nombre;
    private final String id;
    private final String nCelular;
    private final String direcci�n;
    private Carrito carrito;

    public Cliente(String nombre, String id, String nCelular, String direcci�n, int cantProd) {
        this.nombre = nombre;
        this.id = id;
        this.nCelular = nCelular;
        this.direcci�n = direcci�n;
        Carrito carrito = new Carrito (cantProd);
    }

    public boolean buscarProducto (String palabraClave){
        boolean encontrar=false;
        for (int p = 0; p < MakeBDProveedor.getListProv().size(); p++){
            for (int i = 0; i < MakeBDProveedor.getListProv().get(p).getListProd().size(); i++) {
                Producto prod = MakeBDProveedor.getListProv().get(p).getListProd().get(i);
                String palabra = prod.getPalabraClave();
                if(palabra.equalsIgnoreCase(palabraClave)){
                    System.out.println(prod);
                    encontrar=true;
                }
            }
        }
        if (!encontrar)
            System.out.println("No se encontro ningun producto con esa palabra clave. Intente nuevamente");
        return encontrar;
    }
    
    private Producto buscarProductoRef (String reference){
        Producto prodRef=null;
        for (int p = 0; p < MakeBDProveedor.getListProv().size(); p++){
            for (int i = 0; i < MakeBDProveedor.getListProv().get(p).getListProd().size(); i++) {
                Producto prod = MakeBDProveedor.getListProv().get(p).getListProd().get(i);
                String ref = prod.getReferencia();
                if(reference.equalsIgnoreCase(ref)){
                    System.out.println(prod);
                    prodRef=prod;
                }
            }
        }
        if (prodRef==null)
            System.out.println("La referencia no existe. Intente nuevamente");
        return prodRef;
    }
    
    public void comprarProducto (String reference){
        Producto prodComprar = buscarProductoRef(reference);
        if (prodComprar!=null){
            if(prodComprar.getDisponibilidad()>0){
                carrito.elegirMedioPago();
                prodComprar.setDisponibilidad(prodComprar.getDisponibilidad()-1);
                prodComprar.setVendidos(prodComprar.getVendidos()+1);
                for (int p = 0; p < MakeBDProveedor.getListProv().size(); p++){
                    for (int i = 0; i < MakeBDProveedor.getListProv().get(p).getListProd().size(); i++) {
                        Producto prod = MakeBDProveedor.getListProv().get(p).getListProd().get(i);
                        String ref = prod.getReferencia();
                        if(reference.equalsIgnoreCase(ref)){
                            MakeBDProveedor.getListProv().get(p).getListProd().remove(prod);
                            MakeBDProveedor.getListProv().get(p).getListProd().add(prodComprar);
                        }
                    }
                }
            }
            else
                System.out.println("No hay unidades disponibles de esa referencia");
        }
    }
    
    public void update (String nameCateg){
        System.out.println("Se ha publicado un articulo de la categoria " +nameCateg+ ", el cual puede ser de su interes");
    }
    
    public Carrito getCarrito() {
        return carrito;
    }

    public void setCarrito(Carrito carrito) {
        this.carrito = carrito;
    }

    public String getNombre() {
        return nombre;
    }

    public String getId() {
        return id;
    }

    public String getnCelular() {
        return nCelular;
    }

    public String getDirecci�n() {
        return direcci�n;
    }

    @Override
    public String toString() {
        return "Cliente{" + "nombre=" + nombre + ", id=" + id + ", nCelular=" + nCelular + ", direcci\u00f3n=" + direcci�n + ", carrito=" + carrito + '}';
    }
}