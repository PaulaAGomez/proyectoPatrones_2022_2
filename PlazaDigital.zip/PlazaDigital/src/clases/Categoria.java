/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import java.util.ArrayList;

/**
 *
 * @author User
 */
public class Categoria {
    private String nombre;
    private boolean newProduct;
    private ArrayList <Cliente> listObserv = new ArrayList <Cliente> ();

    public Categoria(String categ) {
        this.newProduct = false;
        nombre=categ;
    }
    
    public void register (Cliente observador){
        listObserv.add(observador);
    }
    
    public void unregister (Cliente observador){
        listObserv.remove(observador);
    }
    
    public void notifyClientes (){
        for (int i = 0; i < listObserv.size(); i++) {
            listObserv.get(i).update(nombre);
        }
    }

    public boolean isNewProduct() {
        return newProduct;
    }

    public void setNewProduct(boolean newProduct) {
        this.newProduct = newProduct;
        if (newProduct) 
            notifyClientes();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}