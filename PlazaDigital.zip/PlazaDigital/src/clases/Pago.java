/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author User
 */
public abstract class Pago extends Component{
    private double cantDinero;
    protected Component com;
    
    public Pago solicitarDatos (double cantDinero){
        this.cantDinero = cantDinero;
        return null;
    }

    public double getCantDinero() {
        return cantDinero;
    }

    public void setCantDinero(double cantDinero) {
        this.cantDinero = cantDinero;
    }
    
    public void setTheComponent (Component component){
        com = component;
    }
    
}