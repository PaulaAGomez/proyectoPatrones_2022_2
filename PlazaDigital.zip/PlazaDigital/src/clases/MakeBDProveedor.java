/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import java.util.ArrayList;

/**
 *
 * @author User
 */
public class MakeBDProveedor {
    private static MakeBDProveedor proveedor;
    private static ArrayList <Proveedor> listProv;

    public MakeBDProveedor() {
        listProv = new ArrayList <Proveedor> ();
    }
    
    public static MakeBDProveedor getBDProveedor ( ){
        if (proveedor == null) {
            proveedor = new MakeBDProveedor();
        }
        return proveedor;
    }

    public static ArrayList<Proveedor> getListProv() {
        return listProv;
    }
    
    public static MakeBDProveedor getProveedor() {
        return proveedor;
    }

    public static void setProveedor(MakeBDProveedor proveedor) {
        MakeBDProveedor.proveedor = proveedor;
    }
}