/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author User
 */
public class Ropa extends Categoria implements ICategoriaMyC{

    public Ropa() {
        super.setNombre("Ropa");
    }
    
    public String beneficioProd (){
        return "Este producto est� publicado par satisfacer sus necesidades de ropa";
    }
    
    public void myCategoria (){
        System.out.println("La categoria de este producto es: Ropa");
    }
}