/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author User
 */
public class Hogar extends Categoria implements ICategoriaMyC{

    public Hogar() {
        super.setNombre("Hogar");
    }
    
    public String beneficioProd (){
        return "Este producto est� publicado par satisfacer sus necesidades del hogar";
    }
    
    public void myCategoria (){
        System.out.println("La categoria de este producto es: Hogar");
    }
}