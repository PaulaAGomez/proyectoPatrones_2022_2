/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author User
 */
public class Alimentacion extends Categoria implements ICategoriaMyC {

    public Alimentacion() {
        super.setNombre("Alimentaci�n");
    }
    
    public String beneficioProd (){
        return "Este producto est� publicado par satisfacer sus necesidades de alimentacion";
    }
    
    public void myCategoria (){
        System.out.println("La categoria de este producto es: Alimentaci�n");
    }
}