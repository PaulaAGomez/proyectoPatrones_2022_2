/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package plazadigital;
import clases.*;
import java.util.Scanner;

/**
 *
 * @author User
 */
public class PlazaDigital {
    private MakeBDCliente BDcliente = new MakeBDCliente ();
    
    public static Cliente buscarCliente (String id){
        Cliente clienteRef=null;
        for (int c = 0; c < MakeBDCliente.getListClientes().size(); c++){
            Cliente clt = MakeBDCliente.getListClientes().get(c);
            String idClient = clt.getId();
            if(id.equalsIgnoreCase(idClient)){
                return clt;
            }
        }
        if (clienteRef==null)
            System.out.println("El id no se encuentra. Intente nuevamente");
        return clienteRef; 
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner in = new Scanner (System.in);
        int opcion, opcion2, opcion3;
        String nombre, id, nCelular, direccion;
        Cliente client;
        Producto product;
        do{
            System.out.print("***TIPO DE USUARIO***\n"
                           + "1.Cliente\n"
                           + "2.Proveedor\n"
                           + "0.Salir\n"
                           + "Ingrese el tipo de usuario que mejor lo identifique: ");
            opcion=in.nextInt();
            in.nextLine();
            switch(opcion){
                case 1:
                    do{
                        System.out.println("\n***MENU CLIENTE***\n"
                                         + "1.Registrar cliente"
                                         + "2.Entrar como cliente ya registrado"
                                         + "0.Volver al menu anterior");
                        opcion2=in.nextInt();
                        in.nextLine();
                        switch(opcion2){
                            case 1:
                                System.out.print("Ingrese su nombre: ");
                                nombre=in.nextLine();
                                System.out.print("Ingrese su ID: ");
                                id= in.nextLine();
                                System.out.print("Ingrese su numero de celular: ");
                                nCelular=in.nextLine();
                                System.out.print("Ingrese su direccion: ");
                                direccion=in.nextLine();
                                System.out.print("Ingrese la cantidad de productos que desea llevar en su carrito: ");
                                int cantProd=in.nextInt();
                                in.nextLine();
                                client = new Cliente (nombre, id, nCelular, direccion, cantProd);
                                System.out.println("Se ha creado satisfactoriamente el cliente");
                                break;
                            case 2: 
                                System.out.print("Ingrese su ID: ");
                                id= in.nextLine();
                                client=buscarCliente (id);
                                if(client!=null){
                                    System.out.println("Proveedor encontrado. Ya se encuentra en su usuario");
                                    do{
                                        System.out.println("***CLIENTE REGISTRADO***"
                                                         + "1.Buscar producto por palabra clave"
                                                         + "2.Comprar producto"
                                                         + "0.Volver al menu anterior"
                                                         + "�Qu� acci�n desea realizar? ");
                                        opcion3=in.nextInt();
                                        in.nextLine();
                                        switch(opcion3){
                                            case 1:
                                                System.out.print("Ingrese la palabra clave que desea buscar: ");
                                                String palabraClave=in.nextLine();
                                                client.buscarProducto(palabraClave);
                                                break;
                                            case 2:
                                                System.out.print("Ingrese la referencia del producto que desea comprar: ");
                                                String ref=in.nextLine();
                                                client.comprarProducto(ref);
                                                break;
                                            case 0:
                                                break;
                                            default:
                                                System.out.println("Opcion no valida. Intente nuevamente");
                                                break;
                                        }
                                    }while(opcion3!=0);
                                }else
                                    System.out.println("No se encuentra dentro de la lista de clientes en el sistema. Registres primero para poder continuar"); 
                                break;
                            case 0:
                                break;
                            default:
                                System.out.println("Opcion no valida. Intente nuevamente");
                                break;
                        }
                    }while(opcion2!=0 && opcion2!=2);
                    break;
                    
                case 2:
                    do{
                        System.out.println("\n***MENU PROVEEDOR***\n"
                                         + "1.Registrar proveedor"
                                         + "2.Entrar como proveedor ya registrado"
                                         + "0.Volver al menu anterior");
                        opcion2=in.nextInt();
                        in.nextLine();
                        switch(opcion2){
                            case 1:
                                System.out.print("Ingrese su nombre: ");
                                nombre=in.nextLine();
                                System.out.print("Ingrese su ID: ");
                                id= in.nextLine();
                                System.out.print("Ingrese su numero de celular: ");
                                nCelular=in.nextLine();
                                do{
                                    System.out.println("Para ser proveedor necesita publicar al menos un producto");
                                    System.out.print("Ingrese el nombre del producto: ");
                                    String nomProduct=in.nextLine();
                                    String ref = ((int)(Math.random()*999999))+"";
                                    System.out.print("Ingrese la palabra clave para este producto: ");
                                    String palabraClave=in.nextLine();
                                    System.out.print("Ingrese la descripcion para este producto: ");
                                    String descrip=in.nextLine();
                                    System.out.print("Ingrese la estado para este producto: ");
                                    String estado=in.nextLine();
                                    System.out.println("�Que categoria quiere que sea s programa? (alimento, belleza, hogar, salud, ropa, )");
                                    System.out.print("Ingresen que tenia unas deudas estan ahi para este producto: ");
                                    double precio =in.nextDouble();
                                    product = new Producto (nombre, id, nCelular, new Producto (nomProduct, id, descrip, estado, precios, 1, 1));
                                }while(opcion2 !=0);
                                System.out.println("Se ha creado satisfactoriamente el cliente");
                                break;
                            case 2: 
                                System.out.print("Ingrese su ID: ");
                                id= in.nextLine();
                                client=buscarCliente (id);
                                if(client!=null){
                                    System.out.println("Cliente encontrado. Ya se encuentra en su usuario");
                                    do{
                                        System.out.println("***PROVEEDOR REGISTRADO***"
                                                         + "1.Publicar nuevo producto"
                                                         + "2.Consultar estadisticas del producto"
                                                         + "3.Eliminar producto"
                                                         + "0.Volver al menu anterior"
                                                         + "�Qu� acci�n desea realizar? ");
                                        opcion3=in.nextInt();
                                        in.nextLine();
                                        switch(opcion3){
                                            case 1:
                                                System.out.print("Ingrese la palabra clave que desea buscar: ");
                                                String palabraClave=in.nextLine();
                                                client.buscarProducto(palabraClave);
                                                break;
                                            case 2:
                                                System.out.print("Ingrese la referencia del producto que desea comprar: ");
                                                String ref=in.nextLine();
                                                client.comprarProducto(ref);
                                                break;
                                            case 0:
                                                break;
                                            default:
                                                System.out.println("Opcion no valida. Intente nuevamente");
                                                break;
                                        }
                                    }while(opcion3!=0);
                                }else
                                    System.out.println("No se encuentra dentro de la lista de clientes en el sistema. Registres primero para poder continuar"); 
                                break;
                            case 0:
                                break;
                            default:
                                System.out.println("Opcion no valida. Intente nuevamente");
                                break;
                        }
                    }while(opcion2!=0);
                    break;
                    
                case 0:
                    System.exit(0);
                default:
                    System.out.println("Opcion no valida. Intente nuevamente");
                    break;
            }
        }while(opcion!=0);
    }   
}